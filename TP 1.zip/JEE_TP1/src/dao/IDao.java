
package dao;

public interface IDao {
	double getValue();

}
